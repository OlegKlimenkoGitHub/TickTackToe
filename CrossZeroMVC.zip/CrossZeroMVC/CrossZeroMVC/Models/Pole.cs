﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace CrossZeroMVC.Models
{
    [Serializable]
    public class Pole
    {

        public Cell[] Cells; // массив ячеек
        public int L { get; set; } // Длина ячейки
        public int Width { get; set; } // Количество ячеек по ширине
        public int Heigth { get; set; } // Количество ячеек по высоте
        public Side[] Sides; // массив сторон/граней
        public int indexSides; // индекс сторон/граней
        public int qntSides; // всего сторон/граней

        public Pole()
        { 
        }

        // Конструктор
        public Pole(int _Width, int _Heigth, int _L)
        {
            L = _L;
            Width = _Width;
            Heigth = _Heigth;
            Cells = new Cell[_Width * _Heigth];
            qntSides = 2 * _Width * _Heigth + _Width + _Heigth; // С учетом, что поле может быть прямоугольным
            Sides = new Side[qntSides]; 
            indexSides = 0;

            Create();
            InitializeCells(L * Width, L * Heigth, Color.Black);
        }

        // Создать элементы поля
        public void Create()
        {
            int indexCells = 0;
            for (int x = 1; x <= Width; x++)
            {
                for (int y = 1; y <= Heigth; y++)
                {
                    Point P1 = new Point(x * L - L, y * L - L);
                    Point P2 = new Point(x * L, y * L - L);
                    Point P3 = new Point(x * L, y * L);
                    Point P4 = new Point(x * L - L, y * L);

                    Side sideTop = GetNewSide(P1, P2);
                    Side sideRight = GetNewSide(P2, P3);
                    Side sideDown = GetNewSide(P3, P4);
                    Side sideLeft = GetNewSide(P4, P1);
                    Cells[indexCells] = new Cell(sideTop, sideRight, sideDown, sideLeft);
                    indexCells++;
                }
            }
        }

        // Получить новую грань
        public Side GetNewSide(Point p1, Point p2)
        {
            // Дело в том, что сторона между двумя ячейками, это на самом деле две стороны с одинаковыми координатами
            // и если одна из них закрашена, не факт что закрашена и другая.
            // нужно исключить дублирование сторон при инициализации поля

            foreach (Side side in Sides)
            {
                if (side == null) { continue; }
                if (side.P1 == p1 && side.P2 == p2 ||
                    side.P1 == p2 && side.P2 == p1) 
                { 
                    return side; 
                }
            }

            Sides[indexSides] = new Side(p1, p2);
            indexSides++;
            return Sides[indexSides-1];
        }
        public bool CheckMarked()
        {
            bool isMarked = false;

            foreach (Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 1)
                {
                    isMarked = true;
                    break;
                }                
            }
            return isMarked;
        }
        // Найти незакрашенную грань 
        public Side FindUnmarkedSide()
        {
            Side tSide = null;

            foreach (Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 1)
                {
                    if (!cell.SideTop.Marked()) { tSide = cell.SideTop; }
                    if (tSide == null && !cell.SideRight.Marked()) { tSide = cell.SideRight; }
                    if (tSide == null && !cell.SideDown.Marked()) { tSide = cell.SideDown; }
                    if (tSide == null && !cell.SideLeft.Marked()) { tSide = cell.SideLeft; }
                }
                if (tSide != null)
                    break;
            }
            if (tSide != null)
                return tSide;

            foreach(Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 4)
                {
                    Random rn = new Random();
                    int v = rn.Next(4);
                    // Походим как нибудь
                    if (v == 0) { tSide = cell.SideTop; }
                    if (v == 1) { tSide = cell.SideRight; }
                    if (v == 2) { tSide = cell.SideDown; }
                    if (v == 3) { tSide = cell.SideLeft; }
                }
                if (tSide != null)
                {
                    // Проверить не будет ли это 3-я сторона в соседнем квадрате
                    tSide.setMarked(true);
                    if (!CheckMarked())
                    {
                        tSide.setMarked(false); // Вернем как было
                        break;
                    }
                    tSide.setMarked(false); // Вернем как было и продолжим поиск
                }
            }
            
            if (tSide != null)
            {
                return tSide;
            }

            foreach (Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 3)
                {
                    if (!cell.SideTop.Marked()) { tSide = cell.SideTop; }
                    if (!cell.SideRight.Marked()) { tSide = cell.SideRight; }
                    if (!cell.SideDown.Marked()) { tSide = cell.SideDown; }
                    if (!cell.SideLeft.Marked()) { tSide = cell.SideLeft; }
                }
                if (tSide != null)
                {
                    // Проверить не будет ли это 3-я сторона в соседнем квадрате
                    tSide.setMarked(true);
                    if (!CheckMarked())
                    {
                        tSide.setMarked(false); // Вернем как было
                        break;
                    }
                    tSide.setMarked(false); // Вернем как было и продолжим поиск
                }
            }

            if (tSide != null)
                return tSide;

            foreach (Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 2)
                {
                    if (!cell.SideTop.Marked()) { tSide = cell.SideTop; }
                    if (!cell.SideRight.Marked()) { tSide = cell.SideRight; }
                    if (!cell.SideDown.Marked()) { tSide = cell.SideDown; }
                    if (!cell.SideLeft.Marked()) { tSide = cell.SideLeft; }
                }
                if (tSide != null)
                {
                    //Debug.Print(cell.Print());
                    // Проверить не будет ли это 3-я сторона в соседнем квадрате
                    tSide.setMarked(true);
                    if (!CheckMarked())
                    {
                        tSide.setMarked(false); // Вернем как было
                        break;
                    }
                    tSide.setMarked(false); // Вернем как было и продолжим поиск
                }
            }

            if (tSide != null)
                return tSide;
            
            foreach (Cell cell in Cells)
            {
                if (cell.GetNumUnmarkedSides() == 1)
                {
                    if (!cell.SideTop.Marked()) { tSide = cell.SideTop; }
                    if (!cell.SideRight.Marked()) { tSide = cell.SideRight; }
                    if (!cell.SideDown.Marked()) { tSide = cell.SideDown; }
                    if (!cell.SideLeft.Marked()) { tSide = cell.SideLeft; }
                }
                if (tSide != null)
                    break;
            }
            
            return tSide;

        }

        // Получить грань по координатам
        public Side FindSide(int[] xy) {
            if (xy == null) { return null; }
            foreach (Side side in Sides) {
                if (side.P1.X != xy[0]) { continue; }
                if (side.P1.Y != xy[1]) { continue; }
                if (side.P2.X != xy[2]) { continue; }
                if (side.P2.Y != xy[3]) { continue; }
                return side;
            }
            return null; // Сторона с такими координатами не найдена
        }

        // Получить активную грань
        public Side GetActiveSide (int _X, int _Y)
        {
            foreach (Cell cell in Cells)
            {
                // Не анализируем, если ячейка уже закрашена
                if (cell.SidesMarked()) { continue; }

                if (cell.SideTop.Contains(_X, _Y)) { return cell.SideTop; } 
                if (cell.SideRight.Contains(_X, _Y)) { return cell.SideRight; } 
                if (cell.SideDown.Contains(_X, _Y)) { return cell.SideDown; }
                if (cell.SideLeft.Contains(_X, _Y)) { return cell.SideLeft; } 
            }
            return null;
        
        }

        // Закрасить ячейки у которых выделены все грани
        public bool ChangeMarkStatus(Gamer gamer)
        {
            bool MarkedCell = false;
            foreach (Cell cell in Cells)
            {
                // Не меняем статус, если ячейка уже закрашена
                if (cell.CellMarked()) { continue; }
                // Не меняем статус, если не все стороны ячейки закрашены
                if (!cell.SidesMarked()) { continue;  }

                // Символ и цвет зависят от игрока
                cell.cross = gamer.CrossMan;
                cell.color = gamer.color;

                // Закрасить ячейку
                cell.Draw();

                MarkedCell = true; // Клетка была закрашена
                gamer.Scores++;
            }
            return MarkedCell; // Вернем, была ли закрашена хоть одна клетка
        }

        // Первичная инициализация ячеек
        // Границы игрового поля считаем уже закрашенными
        public void InitializeCells(int MaxX, int MaxY, Color _color)
        {
            foreach (Cell i in Cells)
            {
                if (i.SideTop.P1.Y == 0) { i.SideTop.MarkChoosed(_color); }
                if (i.SideRight.P1.X == MaxX) { i.SideRight.MarkChoosed(_color); }
                if (i.SideDown.P1.Y == MaxY) { i.SideDown.MarkChoosed(_color); }
                if (i.SideLeft.P1.X == 0) { i.SideLeft.MarkChoosed(_color); }
            }
        }

        // Нарисовать все ячейки поля
        public void Draw()
        {
            foreach (Cell cell in Cells)
            {
                cell.Draw();
            }
        }

        // Очистим поле
        public void ClearCells()
        {
            foreach (Cell i in Cells)
            {
                i.marked = false;
                i.cross = false;
                i.Clear();
                
            }
            InitializeCells(L * Width, L * Heigth, Color.Black);
        }
    }
}
