﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace CrossZeroMVC.Models
{
    [Serializable]    
    public class Cell 
    {
        public Side SideTop { get; set; }
        public Side SideRight { get; set; }
        public Side SideDown { get; set; }
        public Side SideLeft { get; set; }

        public bool cross { get; set; } // true - крестик, false - нолик
        public Color color { get; set; }
        public bool marked { get; set; } // true - ячейка зарисована, false - пустая
        public Point center; // координаты центра
        public int length; // ширина/длина фигуры

        public Cell(Side _top, Side _right, Side _down, Side _left)
        {
            SideTop = _top;
            SideRight = _right;
            SideDown = _down;
            SideLeft = _left;
            cross = true;
            color = Color.Black;
            marked = false;
            center.X = SideTop.P2.X - (SideTop.P2.X - SideTop.P1.X) / 2;
            center.Y = SideRight.P2.Y - (SideRight.P2.Y - SideRight.P1.Y) / 2;
            length = 8;
        }

        public Cell(Point P1, Point P2, Point P3, Point P4)
        {
            SideTop = new Side(P1, P2);
            SideRight = new Side(P2, P3);
            SideDown = new Side(P3, P4);
            SideLeft = new Side(P4, P1);
            
            cross = true;
            color = Color.Black;
            marked = false;
        }
       
        public void Draw()
        {
            SideTop.Draw();
            SideRight.Draw();
            SideDown.Draw();
            SideLeft.Draw();
            if (!SidesMarked()) { return; }
            if (cross) { DrawCross(); }
            else { DrawZero(); }
            marked = true;
        }

        public void Clear()
        {
            SideTop.Clear();
            SideRight.Clear();
            SideDown.Clear();
            SideLeft.Clear();
            
            marked = false;
        }

        public bool SidesMarked() // Все стороны ячейки закрашены
        {
            if (!SideTop.Marked()) { return false; }
            if (!SideRight.Marked()) { return false; }
            if (!SideDown.Marked()) { return false; }
            if (!SideLeft.Marked()) { return false; }
            
            return true;
        }

        public int GetNumUnmarkedSides() // Получить количество незакрашенных сторон для ячейки
        {
            int i = 0;
            if (!SideTop.Marked()) { i++; }
            if (!SideRight.Marked()) { i++; }
            if (!SideDown.Marked()) { i++; }
            if (!SideLeft.Marked()) { i++; }
            return i;
        }

        public bool CellMarked() // Ячейка закрашена
        {
            return marked;        
        }

        public void DrawCross()
        {
            if (!SidesMarked()) { return; }
            int x1 = center.X - length;
            int y1 = center.Y - length;
            int x2 = center.X + length;
            int y2 = center.Y + length;
        }

        public void DrawZero()
        {
            if (!SidesMarked()) { return; }
            int Diametr = length * 2;
        }
        public string Print()
        {
            string s = "";

            if (SideTop != null)
                s = s + "T= " + SideTop.Marked().ToString();
            if (SideLeft != null)
                s = s +  " L= " + SideLeft.Marked().ToString();
            if (SideDown != null)
                s = s + " D= " + SideDown.Marked().ToString();
            if (SideRight != null)
                s = s + " R= " + SideRight.Marked().ToString();
            return s;
        }
    }
}
