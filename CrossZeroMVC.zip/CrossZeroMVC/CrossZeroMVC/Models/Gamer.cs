﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossZeroMVC.Models
{
    [Serializable]
    public class Gamer
    {
        public int id { get; set; } // Код игрока
        public string name { get; set; } // имя
        public bool CrossMan { get; set; } // true - крестиками, false - ноликами
        public Color color { get; set; } // цвет игрока
        public int Scores { get; set; } // Набранные баллы

        public Gamer(int _id, string _name, Color _color)  
        {
            id = _id;
            name = _name;
            color = _color;
            Scores = 0;
        }

        public Color GetColor()
        {
            return color;
        }

        public virtual Side move(Pole pole) 
        {
            Side side = pole.FindUnmarkedSide();
            return side;
        }

    }
}
