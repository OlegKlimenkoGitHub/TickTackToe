﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using Newtonsoft.Json;

namespace CrossZeroMVC.Models
{
    [Serializable]
    public class Side
    {
        public bool marked {get; set; } // Признак, что сторона выделена
        private bool active { get; set; } // Признак, что на сторону наехали мышкой
        public decimal D { get; set; } // Толщина стороны, 1/3 пикселя
        public Color color { get; set; } // Цвет стороны
        public String HexColor { get; set; } 
        public Point P1 { get; set; } // Координаты первой точки
        public Point P2 { get; set; } // Координаты второй точки

        Side() { }

        public Side(int x1, int y1, int x2, int y2) {
            D = (decimal)0.5;
            color = Color.Black;
            active = false;
            marked = false;
            P1 = new Point(x1,y1);
            P2 = new Point(x2,y2);
        }

        public Side(Point _P1, Point _P2)
        {
            D = (decimal)0.5;
            color = Color.Black;
            active = false;
            marked = false;
            P1 = _P1;
            P2 = _P2;
        }

        public void MarkActive()
        {
            if (active || Marked()) {return;}
            D = 2;
            color = Color.Red;
            active = true;
        }

        public void MarkInActive()
        {
            if ( !active || Marked()) { return; }
            
            active = false;
            D = (decimal)0.5;
            color = Color.Black;
        }


        public void MarkChoosed(Color _color)
        {
            if (Marked()) { return; }
            D = 2;
            color = _color;
            marked = true;
            active = false;
        }

        public void setMarked( bool bMark)
        {  // Для проверки не закрасим ли мы 3 грани
            marked = bMark;
        }

        public bool Contains(int _X, int _Y)
        {
            if ((Math.Max(P1.X, P2.X) >= _X - 5
              && (Math.Min(P1.X, P2.X)) <= _X + 5
              && (Math.Max(P1.Y, P2.Y)) >= _Y - 5
              && (Math.Min(P1.Y, P2.Y)) <= _Y + 5))
            { return true; }
            else 
            { return false; }
        }

        public void Draw()
        {
        }

        public void Clear()
        {
        }


        public bool Active()
        {
            return active;
        }

        public bool Marked()
        {
            return marked;
        }


    }
}
