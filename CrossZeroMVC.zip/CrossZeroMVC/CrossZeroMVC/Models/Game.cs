﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace CrossZeroMVC.Models
{
    public class Game
    {
        public int maxMarked;
        public int curMarked;
        public Gamer[] gamers; // Массив игроков - людей
        public Gamer activeGamer {get; set;} // Игрок, который сейчас ходит
        public Side activeSide { get; set; } // Линия, которую выбрал игрок
        public Pole pole { get; set; } // Игровое поле

        public Game() {
        }

        public void CreatePole(int width, int height, int sizeOfSide) {
            pole = new Pole(width,height,sizeOfSide);
        }

        public void CreatGamers() {
            gamers = new Gamer[2];

            gamers[0] = new Gamer(1, "Gamer 1", Color.Blue);
            gamers[1] = new Gamer(2, "Computer", Color.Green);
            //gamers[2] = new Gamer(3, "Комп", Color.Orange);

            activeGamer = gamers[0];
        }

        public Pole GetPole() {
            return pole;
        }

        public Side GetActiveSide() {
            if (activeSide == null) { activeSide = new Side(0, 0, 0, 0); }
            return activeSide;
        }

        public void SetActiveSide(Side side) {
            activeSide = side;
        }

        // Передать ход следующему игроку
        public void NextGamer(bool _MarkedCell)
        {
            if (_MarkedCell) { return; } // Если игрок закрасил клетку - нет перехода хода

            if (activeGamer.id == gamers.Length) { activeGamer = gamers[0]; }
            else { activeGamer = gamers[activeGamer.id]; }
        }

        public Gamer GetActiveGamer()
        {
            return activeGamer;
        }

        public void goesPC(Pole MyPole)
        {
            bool MarkedCell = false; // true - ячейка была закрашена, false - ячейка не была закрашена
            Side ChoosedSide;  // Линия, которую выбрал Комп

            activeGamer = GetActiveGamer(); //Определить текущего игрока
            if (activeGamer == null) { return; } // Не выбран игрок

            if (activeGamer.name != "Computer") { return; }

            // Долго придолго ждем
            for (int i = 0; i < 100000000; ++i) ;
                
            // Отработать ход компьютера  
            ChoosedSide = activeGamer.move(MyPole); // Сделать ход, вернуть выбранную сторону

            if (ChoosedSide != null) { ChoosedSide.MarkChoosed(activeGamer.GetColor()); } // Закрасить грань

            MarkedCell = MyPole.ChangeMarkStatus(activeGamer); // закрасить ячейки и вернуть true в случае успеха

            NextGamer(MarkedCell); // Передать ход следующему игроку, если не закрасил ячейку
            goesPC(MyPole); // Ходит компьютер если закрашен квадрат
        }

        public int GetScores(string name)
        {
            foreach (Gamer gamer in gamers)
            {
                if (gamer.name == name)
                    return gamer.Scores;
            }
            return 0;
        }

        public string GetMessage()
        {
            string[] msg = { "Отлично!", "Хорошо!", "Так держать!", "Отличный ход!", "Вперед,к победе!", " Продолжайте!" };
            int i = 0;

            Random rn = new Random();
            i = rn.Next(6);

            return msg[i];
        }

    }
}