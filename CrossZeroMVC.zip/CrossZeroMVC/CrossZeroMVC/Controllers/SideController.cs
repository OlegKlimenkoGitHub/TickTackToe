﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Drawing;
using CrossZeroMVC.Models;

namespace CrossZeroMVC.Controllers
{
    public class SideController : Controller
    {
        //
        // GET: /Side/

        //public Side GetSide ()
        //{
        //    return new Side(new Point(10, 10), new Point(100, 100));
        //}

        //public ActionResult DrawSide()
        //{
        //    Side mySide = new Side(new Point(10,10), new Point(100,100));
        //    return PartialView(mySide);
        //}

    }
}
