﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CrossZeroMVC.Models;
using System.Drawing;
using Newtonsoft.Json;
using System.Threading;
using System.Globalization;

namespace CrossZeroMVC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult NewGame() {
            ViewBag.Message = "";
            Game game = new Game();
            game.CreatePole(12, 8, 50);
            game.CreatGamers();
            Session["game"] = game;
            Pole myPole = game.GetPole();
            Gamer activeGamer = game.GetActiveGamer();

            return View("Index", game);
        }


        public ActionResult Index()
        {
            ViewBag.Message = "";
            Game game = new Game();

            if (Session["game"] == null)
            {
                game.CreatePole(12, 8, 50);
                game.CreatGamers();
                Session["game"] = game;
            }
            else {
                game = Session["game"] as Game;
            }

            Pole myPole = game.GetPole();
            Gamer activeGamer = game.GetActiveGamer();

            return View(game);
        }

        [HttpPost]
        public EmptyResult GetActiveSide(int[] _activeSide)
        {
            bool markedCell = false;
            Game myGame = Session["game"] as Game;
            Pole myPole = myGame.GetPole();
            
            //Найти сторону по полученным координатам
            Side activeSide = myPole.FindSide(_activeSide);
            if (activeSide == null) {
                //вернуть новое состояние представлению 
                return new EmptyResult();
            }
            myGame.SetActiveSide(activeSide);
            
            //Назначить выбранной стороне цвет активного игрока
            Gamer gamer = myGame.GetActiveGamer();
            activeSide.MarkChoosed(gamer.GetColor());

            // Закрасить ячейки у которых выделены все стороны
            markedCell = myPole.ChangeMarkStatus(gamer);

            // Передать ход следующему игроку 
            myGame.NextGamer(markedCell);

            if (myGame.GetActiveGamer().name == "Computer")
            {
                myGame.goesPC(myPole);
            }


            //Этот контроллер ничего не возвращает представлению
            return new EmptyResult();
        }

        [HttpGet]
        public JsonResult GetSides() {
            Game myGame = Session["game"] as Game;
            Pole myPole = myGame.GetPole();

            var jsonData = JsonConvert.SerializeObject(myPole.Sides);

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetCells() {
            Game myGame = Session["game"] as Game;
            Pole myPole = myGame.GetPole();

            var jsonData = JsonConvert.SerializeObject(myPole.Cells);

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetGamers() {
            Game myGame = Session["game"] as Game;

            var jsonData = JsonConvert.SerializeObject(myGame.gamers);

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetActiveGamer() {
            Game myGame = Session["game"] as Game;

            var jsonData = JsonConvert.SerializeObject(myGame.GetActiveGamer().id - 1);

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "My contacts.";

            return View();
        }

        public ActionResult Save() {
            Game myGame = Session["game"] as Game;

            return View();        
        }

        public ActionResult Load()
        {
            return View();
        }

        public ActionResult Change(string lang)
        {
            Session["lang"] = lang;
            if (Session["lang"] == null) Session["lang"] = "en";
            Thread.CurrentThread.CurrentCulture = new CultureInfo(Session["lang"].ToString());
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(Session["lang"].ToString());

            Game myGame = Session["game"] as Game;
            return RedirectToAction("Index", myGame);
        }

    }
}
