﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CrossZeroMVC.Models;
using System.Drawing;

namespace CrossZeroMVC.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

        public ActionResult Index()
        {
            return View();
        }

        public Side GetSide()
        {
            return new Side(new Point(10, 10), new Point(100, 100));
        }

        public Cell GetCell()
        {
            return new Cell(new Point(10, 10), new Point(100, 10), new Point(100, 100), new Point(10, 100));
        }

    }
}
